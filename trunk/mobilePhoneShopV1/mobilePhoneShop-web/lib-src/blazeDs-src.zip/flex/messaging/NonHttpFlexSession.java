package flex.messaging;

public abstract class NonHttpFlexSession extends FlexSession
{

}
