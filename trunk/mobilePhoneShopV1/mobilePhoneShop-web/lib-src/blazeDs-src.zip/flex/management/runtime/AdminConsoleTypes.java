package flex.management.runtime;

public interface AdminConsoleTypes
{
    public static final int GENERAL_SERVER = 1;
    public static final int GENERAL_POLLABLE = 2;
    public static final int GENERAL_OPERATION = 3;
    
    public static final int GRAPH_BY_POLL_INTERVAL = 50;
    
    public static final int ENDPOINT_SCALAR = 100;
    public static final int ENDPOINT_POLLABLE = 101;
    
    public static final int DESTINATION_GENERAL = 150;
    public static final int DESTINATION_POLLABLE = 151;
}
