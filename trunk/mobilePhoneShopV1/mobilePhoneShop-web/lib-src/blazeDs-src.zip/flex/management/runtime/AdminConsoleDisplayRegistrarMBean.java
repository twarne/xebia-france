package flex.management.runtime;

import java.io.IOException;

import flex.management.BaseControlMBean;

public interface AdminConsoleDisplayRegistrarMBean extends BaseControlMBean
{
    
    Integer[] getSupportedTypes() throws IOException;
    
    String[] listForType(int type) throws IOException;
 
}
